# estatais-estados-2020
 
Versão 2020 da história das Empresas dos Estados. Tudo o que foi usado para construí-la está neste repositório, desde os dados originais e o script `R` de análise, até os arquivos da página web.

Está procurando os dados? Eles estão [aqui](./dados/dados.csv).

